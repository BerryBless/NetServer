#include "CCrashDump.h"
long CCrashDump::_dumpCount = 0;
static CCrashDump g_dump;
