// 싱글톤 헤더 모아두는 헤더
#pragma once
#include "CFramework.h"
#include "CSceneManager.h"
#include "CScreenBuffer.h"